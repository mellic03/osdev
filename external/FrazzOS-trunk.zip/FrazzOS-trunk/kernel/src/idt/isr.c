#include "isr.h"
#include "proc/schedule.h"
#include "proc/process.h"
#include "devices/cpu.h"
#include "klibc/io.h"
#include "devices/apic.h"
#include "devices/ps2.h"
#include <flanterm.h>
#include <backends/fb.h>

extern struct flanterm_context* ft_ctx;
extern tcb_t* current_task;

void general_exception_handler() {
    kprint("No exception handler implemented!\n");
    asm volatile("cli; hlt");
}

void divide_by_zero_exception_handler() {
    kprint("Divide by zero exception!\n");
    asm volatile("cli; hlt");
}

void keyboard_irq_handler() {
    keyboard_handler();
    lapic_write_reg(APIC_EOI_REG, 0);
}

void timer_irq_handler() {
    lapic_write_reg(APIC_EOI_REG, 0);

    if (current_task->time_slice == 0) {
        current_task->time_slice = QUANTUM;
        schedule();
    }
    else
        current_task->time_slice--;
}