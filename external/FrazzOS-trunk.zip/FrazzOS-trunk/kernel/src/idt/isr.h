#ifndef ISR_H
#define ISR_H

void general_exception_handler();
void divide_by_zero_exception_handler();

#endif