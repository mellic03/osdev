#ifndef TERMINAL_H
#define TERMINAL_H

#include <limine.h>

void terminal_init();

#endif