#include "gdt/gdt.h"
#include "proc/schedule.h"
#include "proc/process.h"
#include "tss/tss.h"
#include "smp/smp.h"
#include "devices/timer.h"
#include "devices/hpet.h"
#include "mm/vmm.h"
#include "mm/pmm.h"
#include "idt/idt.h"
#include "drivers/terminal.h"
#include "mm/heap.h"
#include "firmware/acpi.h"
#include "klibc/io.h"
#include "klibc/string.h"
#include "klibc/alloc.h"
#include "devices/apic.h"
#include "devices/ioapic.h"
#include "devices/ps2.h"
#include "drivers/graphics/framebuffer.h"
#include "disk/disk.h"

extern struct process* current_task;

// linker script accordingly.
void _start(void) {

    framebuffer_init();
    //terminal_init();
    gdt_init();
    disk_search_and_init();
    idt_init();
    pmm_init();
    vmm_init();
    heap_init();
    acpi_init();
    apic_init();
    ioapic_init();
    ps2_init();
    hpet_init();
    apic_timer_init();
    smp_init();
    init_kernel_cpu_info();
    init_tss();
    init_multitasking();

    // We're done, just hang...
    while (1) {}
}
