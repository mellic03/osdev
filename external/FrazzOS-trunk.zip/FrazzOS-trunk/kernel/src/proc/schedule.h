#ifndef SCHEDULE_H
#define SCHEDULE_H

#include "status.h"
#include "process.h"

void schedule();

#endif